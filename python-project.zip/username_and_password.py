#username_and_password.py

import hashlib,random

def gen_id():
  'Randomise a 10-digit number as the user account via haslib and random / :return:str #account'
  n = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  id = random.sample(n, 10)
  id = ''.join(id)
  return id

def save_data(id,keys):
  with open('user_data.txt', 'a+') as f:
    hashkeys = hashlib.md5(keys.encode(encoding = 'utf-8'))
    hashkeyshex = hashkeys.hexdigest()
    f.write(id+', '+hashkeyshex+'\n')

def login(id,keys):
  with open('user_data.txt', 'r') as f:
    for line in f:
      id_save = line.split(',') [0]
      keys_savehash = line.split(',') [1] [:-1] # This will trim the ending '\n'
      hashkeys = hashlib.md5(keys.encode(encoding = 'utf-8'))
      hashkeyshex = hashkeys.hexdigest()
      if id == id_save and hashkeyshex == keys_savehash:
        return True
    return False