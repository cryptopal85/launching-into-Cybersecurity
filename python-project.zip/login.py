#login.py
from username_and_password import *
print('1. Register //// //// 2. Login')
choice = input('Dear patient, please select the corresponding number to register or login')

if choice == '1':
  id = gen_id()
  print('Your account has been created:',id)
  keys = input('Kindly set your desired password:')
  save_data(id,keys)
  pass

elif choice == '2':
  id = input('Dear patient, please enter the account number:')
  keys = input('Dear patient, please enter the password:')
  if login(id,keys) == True:
    print('login successful')
  else:
    print('Incorrect account or password')
    pass
  
else:
    print('An error occurred while entering the account number or password, login will be terminated automatically')
    exit(1)