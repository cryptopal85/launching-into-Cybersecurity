# Python-based user registration and login script

### The main function of the script
1. As a more straightforward and practical solution, this script does not save the patient's password, but instead stores the patient's password based on the hash algorithm
2. md5 algorithm of the hashlib used as an example

### The main goals
1. The registration process should be designed in a sufficiently secure and practical way. The script does allow patients to create an account, and the script does create the account based on randomly generated 10-digit number
2. In order to eliminate possible risks of storing patient credentials locally, the script allows patients to set their desired password but does not store the password itself in the system. Only the hash value is stored
3. Patients can log in, the script can validate whether the login is successful

### Design Illustration
1. Accounts for patients could be randomly created via functions available in the random module
2. The hash value of passwords could be calculated via functions available in the hashlib module
3. Randomly generated patient account identifiers and password hash values stored in the 'user_data.txt'
4. Patients passwords automatically converted into a hash value to compare hash values stored in the 'user_data.txt'

### Used Data / Test Data
Patient 1 - 5891362047 - 123456
Patient 2 - 3904751862 - 654321
Patient 3 - 4379526108 - abc!123
Patient 4 - 8356097421 - vbn!456

### Sub-Components of the Script
1. login.py // this is the main component of the script where greet Patients. It could be used to register or login to proceed appointment/scheduling process which is not developed yet.
2. username_and_password.py // it is used to randomly generate 10-digit patient account number and hash value for the desired password that set by patients

### Drawbacks and Benefits of MD5 Algorithm
1. Relatively easy to break hashed passwords if we were not creating 10-digit randomised account numbers
2. Could be easily calculated. The MD5 value from the initial data could be easily calculated
3. The length of the calculated MD5 value fixed so it does bring more compressibility
4. It makes more difficult to find a data with the same MD5 value
5. Possible attack vectors could be easily minimised since the 'user_data.txt' possibly could be scrambled


I have zero programming knowledge and this script is my first attempt to fulfill the final module assignment.

With best regards.